package com.example.forum2.mapper;

import com.example.forum2.model.Content;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ContentMapper {
    List<Content> selectAll();
    void updateState(@Param("id") Long id, @Param("state") Integer state);
}