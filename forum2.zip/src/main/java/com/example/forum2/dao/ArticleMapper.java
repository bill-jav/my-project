package com.example.forum2.dao;

import com.example.forum2.model.Article;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ArticleMapper {
    int insert(Article row);

    int insertSelective(Article row);

    Article selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Article row);

    int updateByPrimaryKeyWithBLOBs(Article row);

    int updateByPrimaryKey(Article row);

    List<Article> selectAll();

    List<Article> selectByBoardId(@Param("boardId") Long boardId);

    Article selectDetailById(@Param("id") Long id);

    List<Article> selectByUserId(@Param("userId") Long userId);

}