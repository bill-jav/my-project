package com.example.forum2.model;

import java.util.Date;

public class Content {
    private Long id;
    private String title;
    private String author;
    private String content;
    private Date createTime;
    private Integer state; // 0-正常，1-禁用

    // getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public Date getCreateTime() { return createTime; }
    public void setCreateTime(Date createTime) { this.createTime = createTime; }

    public Integer getState() { return state; }
    public void setState(Integer state) { this.state = state; }
}