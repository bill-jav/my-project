package com.example.forum2.service.impl;

import com.example.forum2.mapper.ContentMapper; // 需要创建 ContentMapper
import com.example.forum2.model.Content;
import com.example.forum2.service.ContentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ContentServiceImpl implements ContentService {

    @Autowired
    private ContentMapper contentMapper; // 需要创建 ContentMapper

    @Override
    public List<Content> getAllContents() {
        return contentMapper.selectAll();
    }

    @Override
    public void disableContent(Long contentId) {
        contentMapper.updateState(contentId, 1); // 1表示禁用
    }

    @Override
    public void enableContent(Long contentId) {
        contentMapper.updateState(contentId, 0); // 0表示启用
    }
}