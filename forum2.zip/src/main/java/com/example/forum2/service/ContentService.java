package com.example.forum2.service;

import com.example.forum2.model.Content;
import java.util.List;

public interface ContentService {
    List<Content> getAllContents();
    void disableContent(Long contentId);
    void enableContent(Long contentId);
}