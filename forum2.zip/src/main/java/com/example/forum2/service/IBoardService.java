package com.example.forum2.service;


import com.example.forum2.model.Board;



import java.util.List;



public interface IBoardService {


    List<Board> selectTopByNum(Integer num);
    Board selectByPrimaryKey(Long id);
    /**
     * 管理员获取所有板块列表
     * @return 板块列表
     */
    List<Board> getAllBoards();

    /**
     * 管理员禁用板块
     * @param boardId 板块ID
     */
    void disableBoard(Long boardId);

    /**
     * 管理员启用板块
     * @param boardId 板块ID
     */
    void enableBoard(Long boardId);


}
