package com.example.forum2.service.impl;

import com.example.forum2.dao.BoardMapper;
import com.example.forum2.model.Board;
import com.example.forum2.service.IBoardService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class BoardServiceImpl implements IBoardService {

    @Resource
    private BoardMapper boardMapper;

    // 实现 IBoardService 接口的 selectTopByNum 方法
    @Override
    public List<Board> selectTopByNum(Integer num) {
        return boardMapper.selectTopByNum(num);
    }

    // 实现 IBoardService 接口的 selectByPrimaryKey 方法
    @Override
    public Board selectByPrimaryKey(Long id) {
        return boardMapper.selectByPrimaryKey(id);
    }

    // 已有方法...
    @Override
    public List<Board> getAllBoards() {
        return boardMapper.selectAllBoards();
    }

    @Override
    public void disableBoard(Long boardId) {
        Board board = boardMapper.selectByPrimaryKey(boardId);
        if (board != null) {
            board.setState((byte) 1); // 设置板块状态为禁用
            boardMapper.updateByPrimaryKeySelective(board);
        }
    }

    // 添加缺失的方法实现
    @Override
    public void enableBoard(Long boardId) {
        Board board = boardMapper.selectByPrimaryKey(boardId);
        if (board != null) {
            board.setState((byte) 0); // 设置板块状态为启用
            boardMapper.updateByPrimaryKeySelective(board);
        }
    }
}