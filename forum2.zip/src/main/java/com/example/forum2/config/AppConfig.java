package com.example.forum2.config;

public class AppConfig {
    public final static String USER_SESSION="USER_SESSION";
}
