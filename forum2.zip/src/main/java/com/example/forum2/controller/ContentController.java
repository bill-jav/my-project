package com.example.forum2.controller;

import com.example.forum2.common.AppResult;
import com.example.forum2.model.Content; // 假设 Content 类存在，需要根据实际情况调整
import com.example.forum2.service.ContentService; // 假设 ContentService 类存在，需要根据实际情况调整
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/content/admin")
public class ContentController {

    @Autowired
    private ContentService contentService;

    // 获取所有内容
    @GetMapping("/getAllContents")
    public AppResult<List<Content>> getAllContents() {
        List<Content> contents = contentService.getAllContents();
        return AppResult.success(contents);
    }

    // 其他接口（禁用/启用内容）
    // ...
}