package com.example.forum2.controller;

import com.example.forum2.common.AppResult;
import com.example.forum2.common.ResultCode;
import com.example.forum2.config.AppConfig;
import com.example.forum2.model.Board;
import com.example.forum2.model.User; // 引入 User 类
import com.example.forum2.service.IBoardService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Slf4j
@Api(tags = "板块接口")
@RestController
@RequestMapping("/board")
public class BoardController {

    @Resource
    private IBoardService iBoardService;

    @Value("${forum.index.board-num}")
    private  Integer indexBoardNum;

    @ApiOperation(value = "主页中显示的版块")
    @GetMapping("/topList")
    public AppResult<List<Board>> getTop(){
        log.info("从配置文件中读取到的版块数量为：" + indexBoardNum);
        List<Board> result = iBoardService.selectTopByNum(indexBoardNum);
        return AppResult.success(result);
    }

    @ApiOperation(value = "获取板块详情")
    @GetMapping("/getById")
    public AppResult<Board> getById(@ApiParam(value = "板块Id") @RequestParam("id" ) @NonNull Long id){
        Board board = iBoardService.selectByPrimaryKey(id);
        return AppResult.success(board);
    }

    @ApiOperation("管理员获取所有板块列表")
    @GetMapping("/admin/getAllBoards")
    public AppResult<List<Board>> getAllBoards(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute(AppConfig.USER_SESSION);
        if (user == null || user.getIsAdmin() == 0) {
            return AppResult.failed(ResultCode.FAILED_FORBIDDEN);
        }
        List<Board> boards = iBoardService.getAllBoards();
        return AppResult.success(boards);
    }

    @ApiOperation("管理员禁用板块")
    @PostMapping("/admin/disableBoard")
    public AppResult disableBoard(HttpServletRequest request,
                                  @ApiParam("板块ID") @RequestParam("boardId") @NonNull Long boardId) {
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute(AppConfig.USER_SESSION);
        if (user == null || user.getIsAdmin() == 0) {
            return AppResult.failed(ResultCode.FAILED_FORBIDDEN);
        }
        iBoardService.disableBoard(boardId);
        return AppResult.success();
    }

    @ApiOperation("管理员启用板块")
    @PostMapping("/admin/enableBoard")
    public AppResult enableBoard(HttpServletRequest request,
                                 @ApiParam("板块ID") @RequestParam("boardId") @NonNull Long boardId) {
        HttpSession session = request.getSession(false);
        User user = (User) session.getAttribute(AppConfig.USER_SESSION);
        if (user == null || user.getIsAdmin() == 0) {
            return AppResult.failed(ResultCode.FAILED_FORBIDDEN);
        }
        iBoardService.enableBoard(boardId);
        return AppResult.success();
    }
}