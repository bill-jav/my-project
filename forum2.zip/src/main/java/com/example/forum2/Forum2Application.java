package com.example.forum2;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.*;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.util.*;

@SpringBootApplication
@MapperScan("com.example.forum2.mapper")
public class Forum2Application implements CommandLineRunner {

    private final Environment env;
    private final ConfigurableApplicationContext context;

    public Forum2Application(Environment env, ConfigurableApplicationContext context) {
        this.env = env;
        this.context = context;
    }

    public static void main(String[] args) {
        System.out.println("=== 应用启动诊断 ===");

        // 打印类路径
        System.out.println("Java 类路径:");
        String classPath = System.getProperty("java.class.path");
        for (String path : classPath.split(System.getProperty("path.separator"))) {
            System.out.println("- " + path);
        }

        // 检查 application.yml 是否在类路径中
        try {
            ClassPathResource resource = new ClassPathResource("application.yml");
            System.out.println("\napplication.yml 存在: " + resource.exists());
            if (resource.exists()) {
                System.out.println("application.yml 位置: " + resource.getURI());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("应用启动中...");
        SpringApplication.run(Forum2Application.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        System.out.println("\n=== 应用上下文已加载 ===");
        // 打印数据源配置
        System.out.println("数据源配置:");
        System.out.println("URL: " + env.getProperty("spring.datasource.url"));
        System.out.println("用户名: " + env.getProperty("spring.datasource.username"));
        System.out.println("驱动类: " + env.getProperty("spring.datasource.driver-class-name"));

        // 检查数据源 bean 是否存在
        System.out.println("数据源 Bean 是否存在: " + context.containsBean("dataSource"));

        System.out.println("\n=== 配置信息 ===");
        System.out.println("数据库URL: " + env.getProperty("spring.datasource.url"));
        System.out.println("用户名: " + env.getProperty("spring.datasource.username"));
        System.out.println("驱动类: " + env.getProperty("spring.datasource.driver-class-name"));

        // 修正：遍历所有属性源收集属性名
        System.out.println("\n=== 环境属性 ===");
        Map<String, Object> allProperties = getAllProperties(env);
        for (String propertyName : allProperties.keySet()) {
            if (propertyName.startsWith("spring.datasource")) {
                System.out.println(propertyName + " = " + allProperties.get(propertyName));
            }
        }
    }

    // 辅助方法：收集所有属性名和值
    private Map<String, Object> getAllProperties(Environment env) {
        Map<String, Object> result = new HashMap<>();
        if (env instanceof ConfigurableEnvironment) {
            for (PropertySource<?> propertySource : ((ConfigurableEnvironment) env).getPropertySources()) {
                if (propertySource instanceof EnumerablePropertySource) {
                    EnumerablePropertySource<?> eps = (EnumerablePropertySource<?>) propertySource;
                    for (String key : eps.getPropertyNames()) {
                        result.put(key, eps.getProperty(key));
                    }
                }
            }
        }
        return result;
    }
}