// =================== 定义全局变量 ======================
let avatarUrl = 'image/avatar01.jpeg'; // 默认头像
let currentArticle; // 当前访问的帖子
let currentUserId;  // 当前登录用户
let profileUserId;  // 查看个人信息
// ============================ 处理导航激活效果 ===========================
function changeNavActive (boardItem) {
    // 判断当前是否为激活状态
    if (boardItem.hasClass('active') == false) {
        let activeLiEl = $('#topBoardList>.active');
        activeLiEl.removeClass('active');
        boardItem.addClass('active');
        console.log('修改');
        // 请求版块中的帖子
        buildArticleList();
    }
}

// ============================ 删除导航激活效果 ===========================
function removeNavActive () {
    // 判断当前是否为激活状态
    let activeLiEl = $('#topBoardList>.active');
    if (activeLiEl) {
        activeLiEl.removeClass('active');
    }
}

//======================= 处理导航栏点击并获取帖子列表 ======================
function buildArticleList() {
    console.log('加载文章列表页面');
    $('#bit-forum-content').load('article_list.html', function() {
        // 页面加载完成后可以添加初始化逻辑
        initArticleList();
    });
}

// 初始化文章列表（可选）
function initArticleList() {
    // 添加文章列表的交互逻辑
    console.log('初始化文章列表');
}

// 在 src/main/resources/static/js/common.js 中添加菜单点击事件处理
$(document).ready(function() {
    // 管理员用户管理菜单点击事件
    $('#index_admin_user_management').click(function () {
        $.ajax({
            type: 'get',
            url: 'user/admin/getAllUsers',
            success: function (respData) {
                if (respData.code == 0) {
                    console.log('获取用户列表成功:', respData.data);
                    // 加载用户管理页面并渲染数据
                    $('#bit-forum-content').load('admin_user_list.html', function () {
                        renderUserList(respData.data);
                    });
                } else {
                    $.toast({
                        heading: '提示',
                        text: respData.message,
                        icon: 'info'
                    });
                }
            },
            error: function (respData) {
                $.toast({
                    heading: '错误',
                    text: respData.message,
                    icon: 'error'
                });
            }
        });
    });

    // 渲染用户列表
    function renderUserList(users) {
        const tableBody = $('#user-table-body');
        tableBody.empty(); // 清空表格

        if (users.length === 0) {
            tableBody.html('<tr><td colspan="6" class="text-center">没有用户数据</td></tr>');
            return;
        }

        // 遍历用户数据，生成表格行
        users.forEach(user => {
            const role = user.isAdmin ? '管理员' : '普通用户';
            const status = user.state === 0 ? '正常' : '禁用';
            const statusClass = user.state === 0 ? 'text-success' : 'text-danger';

            const row = `
            <tr>
                <td>${user.id}</td>
                <td>${user.username}</td>
                <td>${user.nickname}</td>
                <td>${role}</td>
                <td><span class="${statusClass}">${status}</span></td>
                <td>
                    <button class="btn btn-sm btn-primary" onclick="editUser(${user.id})">编辑</button>
                    ${user.isAdmin ? '' : `
                    <button class="btn btn-sm ${user.state === 0 ? 'btn-danger' : 'btn-success'}" 
                            onclick="${user.state === 0 ? 'disableUser' : 'enableUser'}(${user.id})">
                        ${user.state === 0 ? '禁用' : '启用'}
                    </button>`}
                </td>
            </tr>
        `;
            tableBody.append(row);
        });
    }

    // 编辑用户（示例函数，需根据实际需求实现）
    function editUser(userId) {
        console.log('编辑用户:', userId);
        // TODO: 实现编辑用户逻辑
    }

    // 禁用用户
    function disableUser(userId) {
        if (confirm('确定要禁用此用户吗？')) {
            $.ajax({
                type: 'post',
                url: 'user/admin/disableUser',
                data: {userId},
                success: function (respData) {
                    if (respData.code == 0) {
                        $.toast({
                            heading: '成功',
                            text: '用户已禁用',
                            icon: 'success'
                        });
                        // 刷新用户列表
                        $('#index_admin_user_management').trigger('click');
                    } else {
                        $.toast({
                            heading: '失败',
                            text: respData.message,
                            icon: 'error'
                        });
                    }
                },
                error: function () {
                    $.toast({
                        heading: '错误',
                        text: '请求失败',
                        icon: 'error'
                    });
                }
            });
        }
    }

    // 启用用户
    function enableUser(userId) {
        if (confirm('确定要启用此用户吗？')) {
            $.ajax({
                type: 'post',
                url: 'user/admin/enableUser',
                data: {userId},
                success: function (respData) {
                    if (respData.code == 0) {
                        $.toast({
                            heading: '成功',
                            text: '用户已启用',
                            icon: 'success'
                        });
                        // 刷新用户列表
                        $('#index_admin_user_management').trigger('click');
                    } else {
                        $.toast({
                            heading: '失败',
                            text: respData.message,
                            icon: 'error'
                        });
                    }
                },
                error: function () {
                    $.toast({
                        heading: '错误',
                        text: '请求失败',
                        icon: 'error'
                    });
                }
            });
        }
    }

    // 内容管理菜单点击事件
    $('#index_admin_content_management').click(function() {
        $.ajax({
            type: 'get',
            url: 'content/admin/getAllContents',  // 新接口
            success: function(respData) {
                if (respData.code == 0) {
                    console.log('获取内容列表成功:', respData.data);
                    // 加载内容管理页面并渲染数据
                    $('#bit-forum-content').load('admin_content_list.html', function() {
                        renderContentList(respData.data);
                    });
                } else {
                    $.toast({
                        heading: '提示',
                        text: respData.message,
                        icon: 'info'
                    });
                }
            },
            error: function(respData) {
                $.toast({
                    heading: '错误',
                    text: respData.message,
                    icon: 'error'
                });
            }
        });
    });

    // 渲染内容列表（新增函数）
    function renderContentList(contents) {
        const tableBody = $('#content-table-body');
        tableBody.empty(); // 清空表格

        if (contents.length === 0) {
            tableBody.html('<tr><td colspan="6" class="text-center">没有内容数据</td></tr>');
            return;
        }

        // 遍历内容数据，生成表格行
        contents.forEach(content => {
            const status = content.state === 0 ? '正常' : '禁用';
            const statusClass = content.state === 0 ? 'text-success' : 'text-danger';

            const row = `
                <tr>
                    <td>${content.id}</td>
                    <td>${content.title}</td>
                    <td>${content.author}</td>
                    <td>${new Date(content.createTime).toLocaleString()}</td>
                    <td><span class="${statusClass}">${status}</span></td>
                    <td>
                        <button class="btn btn-sm btn-primary" onclick="editContent(${content.id})">编辑</button>
                        ${content.state === 0 ?
                `<button class="btn btn-sm btn-danger" onclick="disableContent(${content.id})">禁用</button>` :
                `<button class="btn btn-sm btn-success" onclick="enableContent(${content.id})">启用</button>`}
                    </td>
                </tr>
            `;
            tableBody.append(row);
        });
    }

    // 编辑内容（示例函数，需根据实际需求实现）
    function editContent(contentId) {
        console.log('编辑内容:', contentId);
        // TODO: 实现编辑内容逻辑
    }

    // 禁用内容
    function disableContent(contentId) {
        if (confirm('确定要禁用此内容吗？')) {
            $.ajax({
                type: 'post',
                url: 'content/admin/disableContent',
                data: { contentId },
                success: function(respData) {
                    if (respData.code == 0) {
                        $.toast({
                            heading: '成功',
                            text: '内容已禁用',
                            icon: 'success'
                        });
                        // 刷新内容列表
                        $('#index_admin_content_management').trigger('click');
                    } else {
                        $.toast({
                            heading: '失败',
                            text: respData.message,
                            icon: 'error'
                        });
                    }
                },
                error: function() {
                    $.toast({
                        heading: '错误',
                        text: '请求失败',
                        icon: 'error'
                    });
                }
            });
        }
    }

    // 启用内容
    function enableContent(contentId) {
        if (confirm('确定要启用此内容吗？')) {
            $.ajax({
                type: 'post',
                url: 'content/admin/enableContent',
                data: { contentId },
                success: function(respData) {
                    if (respData.code == 0) {
                        $.toast({
                            heading: '成功',
                            text: '内容已启用',
                            icon: 'success'
                        });
                        // 刷新内容列表
                        $('#index_admin_content_management').trigger('click');
                    } else {
                        $.toast({
                            heading: '失败',
                            text: respData.message,
                            icon: 'error'
                        });
                    }
                },
                error: function() {
                    $.toast({
                        heading: '错误',
                        text: '请求失败',
                        icon: 'error'
                    });
                }
            });
        }
    }
});